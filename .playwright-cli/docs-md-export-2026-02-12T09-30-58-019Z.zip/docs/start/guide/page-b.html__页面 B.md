---
title: "页面 B"
source: "https://zip-e2e.invalid/docs/start/guide/page-b.html"
---
# 页面 B

页面 B 用于补充多层路径目录结构，验证导出的 ZIP 中目录与 SUMMARY 文件是否按预期生成。

回到 [开始页](https://zip-e2e.invalid/docs/start/index.html)。
